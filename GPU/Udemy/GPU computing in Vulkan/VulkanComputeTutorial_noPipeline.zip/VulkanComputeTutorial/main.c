#include "compute.h"
#include "instance.h"
#include "device.h"

int main(int ac, char **av)
{
    CreateInstance();
    GetPhysicalDevice();
    CreateDeviceAndComputeQueue();
    CreateCommandPool();
    PrepareCommandBuffer();
    Compute();
    DestroyCommandPoolAndLogicalDevice();

    return 0;
}