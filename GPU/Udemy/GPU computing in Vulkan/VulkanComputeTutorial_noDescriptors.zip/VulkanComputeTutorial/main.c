#include "compute.h"
#include "instance.h"
#include "device.h"
#include "pipeline.h"

int main(int ac, char **av)
{
    CreateInstance();
    GetPhysicalDevice();
    CreateDeviceAndComputeQueue();
    CreatePipeline();
    CreateCommandPool();
    PrepareCommandBuffer();
    Compute();
    DestroyPipeline();
    DestroyCommandPoolAndLogicalDevice();

    return 0;
}